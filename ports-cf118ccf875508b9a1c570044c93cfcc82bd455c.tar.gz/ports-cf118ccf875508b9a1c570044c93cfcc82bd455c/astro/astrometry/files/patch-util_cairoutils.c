--- util/cairoutils.c.orig	2015-12-12 19:02:27 UTC
+++ util/cairoutils.c
@@ -12,6 +12,7 @@
 
 #include <cairo.h>
 #include <png.h>
+#include <zlib.h>
 #include <jpeglib.h>
 #include <zlib.h>
 

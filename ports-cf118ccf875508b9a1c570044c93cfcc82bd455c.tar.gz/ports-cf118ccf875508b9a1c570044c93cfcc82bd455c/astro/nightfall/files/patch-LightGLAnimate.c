--- LightGLAnimate.c.orig	2014-05-13 08:45:46 UTC
+++ LightGLAnimate.c
@@ -25,6 +25,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
+#include <sys/types.h>
 #include "Light.h"
 
 #ifdef  _WITH_OPENGL

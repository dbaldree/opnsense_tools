--- src/ou.h.orig	2000-06-04 19:35:09 UTC
+++ src/ou.h
@@ -19,6 +19,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <math.h>
 
 #ifdef WIN32

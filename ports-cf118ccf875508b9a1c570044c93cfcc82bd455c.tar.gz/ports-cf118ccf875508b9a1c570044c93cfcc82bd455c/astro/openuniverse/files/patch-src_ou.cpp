--- src/ou.cpp.orig	2000-06-04 21:29:29 UTC
+++ src/ou.cpp
@@ -22,7 +22,7 @@
 #include <string.h>
 #include <math.h>
 #include <time.h>
-#include <sys/timeb.h>
+#include "timeb.h"
 #include <setjmp.h>
 #include "ou.h"
 #include "gui.h"

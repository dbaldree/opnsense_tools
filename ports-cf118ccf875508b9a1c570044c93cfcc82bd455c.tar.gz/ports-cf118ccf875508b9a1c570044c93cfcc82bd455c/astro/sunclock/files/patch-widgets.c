--- widgets.c.orig	2011-07-09 09:51:18 UTC
+++ widgets.c
@@ -1,6 +1,5 @@
 #include <unistd.h>
 #include <sys/types.h>
-#include <sys/timeb.h>
 #include <sys/stat.h>
 #include <string.h>
 

--- tildepath.c.orig	2000-09-01 15:34:51 UTC
+++ tildepath.c
@@ -38,7 +38,6 @@ T* AUTHOR
 #include <stdio.h>
 #include <stdlib.h>
 #include <pwd.h>
-#include <malloc.h>
 #include <string.h>
 
 /*

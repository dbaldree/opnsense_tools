--- ap_remove_radar.cpp.orig	2012-01-26 06:53:16 UTC
+++ ap_remove_radar.cpp
@@ -1,5 +1,4 @@
 #include "astropulse.h"
-#include "ap_graphics.h"
 #include "fftw3.h"
 #include "sbtf.h"
 #include "ap_debug.h"

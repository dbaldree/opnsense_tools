--- ap_fileio.cpp.orig	2012-02-27 23:01:04 UTC
+++ ap_fileio.cpp
@@ -22,6 +22,7 @@
 #include "windows.h"
 #endif
 
+#include <cmath>
 #include <cstdio>
 #include <cstdlib>
 #include <vector>

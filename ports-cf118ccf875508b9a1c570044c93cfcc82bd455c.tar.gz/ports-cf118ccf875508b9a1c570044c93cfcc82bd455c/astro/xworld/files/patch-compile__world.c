--- compile_world.c.orig	1999-07-28 13:13:51 UTC
+++ compile_world.c
@@ -33,6 +33,7 @@
 #include <sys/types.h>
 #include <sys/mman.h>
 #include <stdio.h>
+#include <stdlib.h>
 #include "Sphere.h"
 #include "SphereDim.h"
 

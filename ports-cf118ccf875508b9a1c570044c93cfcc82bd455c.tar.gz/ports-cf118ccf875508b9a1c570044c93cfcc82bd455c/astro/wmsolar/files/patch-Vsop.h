--- Vsop.h.orig	2016-07-26 13:20:30 UTC
+++ Vsop.h
@@ -12,6 +12,7 @@
 #define VSOP__H
 
 #include "PlanetData.h"  // for enum Planet
+#include <math.h>
 
 // * * * * * simple support structs * * * * *
 

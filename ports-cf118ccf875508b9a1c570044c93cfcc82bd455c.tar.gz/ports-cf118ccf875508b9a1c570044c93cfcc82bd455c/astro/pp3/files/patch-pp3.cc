--- pp3.cc.orig	2004-08-14 16:45:08 UTC
+++ pp3.cc
@@ -15,6 +15,7 @@
 #include <cstdlib> 
 #include <cmath> 
 #include <cfloat> 
+#include <cstring>
 
 using namespace std;
 

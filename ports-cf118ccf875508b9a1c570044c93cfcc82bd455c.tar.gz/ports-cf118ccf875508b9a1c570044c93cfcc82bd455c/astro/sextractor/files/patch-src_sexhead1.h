--- src/sexhead1.h.orig	2005-10-24 11:48:52 UTC
+++ src/sexhead1.h
@@ -15,8 +15,8 @@
 */
 
 
-int	idummy;
-double	ddummy;
+EXTERN int	idummy;
+EXTERN double	ddummy;
 
 keystruct	headkey1[] = {
   {"EPOCH   ", "",

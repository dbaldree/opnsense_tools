--- src/clean.h.orig	2005-10-24 11:48:52 UTC
+++ src/clean.h
@@ -22,7 +22,7 @@
 
 /*------------------------------- variables ---------------------------------*/
 
-objliststruct	*cleanobjlist;		/* laconic, isn't it? */
+EXTERN objliststruct	*cleanobjlist;		/* laconic, isn't it? */
 
 /*------------------------------- functions ---------------------------------*/
 

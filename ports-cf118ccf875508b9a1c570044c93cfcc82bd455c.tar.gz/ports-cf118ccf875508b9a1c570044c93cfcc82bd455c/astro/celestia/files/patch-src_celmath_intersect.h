--- src/celmath/intersect.h.orig	2011-06-06 00:11:15.000000000 +0800
+++ src/celmath/intersect.h	2013-06-16 02:00:47.000000000 +0800
@@ -12,6 +12,7 @@
 #ifndef _CELMATH_INTERSECT_H_
 #define _CELMATH_INTERSECT_H_
 
+#include "mathlib.h"
 #include "ray.h"
 #include "sphere.h"
 #include "ellipsoid.h"

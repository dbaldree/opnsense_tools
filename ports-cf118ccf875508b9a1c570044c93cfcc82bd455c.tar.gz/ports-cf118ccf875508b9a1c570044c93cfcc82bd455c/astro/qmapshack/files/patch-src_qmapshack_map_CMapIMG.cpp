--- src/qmapshack/map/CMapIMG.cpp.orig	2020-05-21 11:11:11 UTC
+++ src/qmapshack/map/CMapIMG.cpp
@@ -33,6 +33,7 @@
 #include "units/IUnit.h"
 
 #include <QtWidgets>
+#include <QPainterPath>
 
 #undef DEBUG_SHOW_SECT_DESC
 #undef DEBUG_SHOW_TRE_DATA

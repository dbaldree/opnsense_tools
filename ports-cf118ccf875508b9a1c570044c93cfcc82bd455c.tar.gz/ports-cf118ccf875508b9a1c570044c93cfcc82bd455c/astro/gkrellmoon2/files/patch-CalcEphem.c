--- CalcEphem.c.orig	2002-12-11 03:36:06 UTC
+++ CalcEphem.c
@@ -8,6 +8,7 @@
 #ifdef HAVE_CONFIG_H
 #include <config.h>
 #endif
+#include <string.h>
 
 #include "CalcEphem.h"
 #include "Moon.h"

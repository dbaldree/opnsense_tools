--- ../wmgeneral/wmgeneral.h.orig	2020-12-21 11:21:23.324171000 -0600
+++ ../wmgeneral/wmgeneral.h	2020-12-21 11:21:41.194688000 -0600
@@ -28,7 +28,7 @@
  /* Global variable */
 /*******************/
 
-Display		*display;
+extern Display		*display;
 
   /***********************/
  /* Function Prototypes */

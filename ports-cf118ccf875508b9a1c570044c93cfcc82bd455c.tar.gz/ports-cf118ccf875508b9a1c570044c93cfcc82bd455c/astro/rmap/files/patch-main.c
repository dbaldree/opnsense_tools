--- main.c.orig	2000-03-28 16:01:17 UTC
+++ main.c
@@ -154,7 +154,7 @@ int main (int argc, char **argv) {
 			case 'h':
 				printf("Usage: rmap [--zoom=VALUE] [--xrot=VALUE] [--yrot=VALUE] [--zrot=VALUE]\n");
 				printf("            [--datafile=FILENAME] [--continent=LIST] [--category=LIST]\n");
-				printf("            [--outfile=FILENAME] [--height=PIXLES] [--width=PIXLES]\n");
+				printf("            [--outfile=FILENAME] [--height=PIXELS] [--width=PIXELS]\n");
 				printf("            [--colorfile=FILENAME] [--nogridlines] [--cities] [-h] [-v]\n");
 				printf("\n");	
 				printf("\t--zoom=<value>             Zoom Value, 1=whole earth\n");

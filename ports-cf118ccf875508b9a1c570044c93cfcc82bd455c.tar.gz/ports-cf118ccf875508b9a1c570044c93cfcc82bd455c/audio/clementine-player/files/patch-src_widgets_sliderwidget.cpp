--- src/widgets/sliderwidget.cpp.orig	2020-05-19 17:48:49 UTC
+++ src/widgets/sliderwidget.cpp
@@ -24,6 +24,7 @@
 #include <QBrush>
 #include <QImage>
 #include <QPainter>
+#include <QPainterPath>
 #include <QSize>
 #include <QTimer>
 #include <QStyle>

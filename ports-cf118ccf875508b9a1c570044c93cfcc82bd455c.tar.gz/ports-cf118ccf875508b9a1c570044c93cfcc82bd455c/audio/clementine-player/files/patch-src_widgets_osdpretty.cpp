--- src/widgets/osdpretty.cpp.orig	2020-05-19 17:43:09 UTC
+++ src/widgets/osdpretty.cpp
@@ -26,6 +26,7 @@
 #include <QLayout>
 #include <QMouseEvent>
 #include <QPainter>
+#include <QPainterPath>
 #include <QSettings>
 #include <QTimer>
 #include <QTimeLine>

Index: version.h
===================================================================
RCS file: /home/cvs/cdparanoia/version.h,v
retrieving revision 1.1.1.1
retrieving revision 1.2
--- version.h.orig	2001-03-24 01:15:45 UTC
+++ version.h
@@ -8,6 +8,8 @@
 
 
 #define VERSION "cdparanoia III release 9.8 (March 23, 2001)\n"\
-                "(C) 2001 Monty <monty@xiph.org> and Xiphophorus\n\n"\
+                "(C) 2001 Monty <monty@xiph.org> and Xiphophorus\n"\
+		"FreeBSD porting (c) 2003\n"\
+		"\tSimon 'corecode' Schubert <corecode@corecode.ath.cx>\n\n"\
 		"Report bugs to paranoia@xiph.org\n"\
 		"http://www.xiph.org/paranoia/\n"

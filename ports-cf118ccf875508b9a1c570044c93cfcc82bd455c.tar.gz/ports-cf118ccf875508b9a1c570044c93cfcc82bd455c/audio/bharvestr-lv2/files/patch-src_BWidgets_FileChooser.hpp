--- src/BWidgets/FileChooser.hpp.orig	2020-07-20 09:39:49 UTC
+++ src/BWidgets/FileChooser.hpp
@@ -24,6 +24,7 @@
 #include "PopupListBox.hpp"
 #include "TextButton.hpp"
 #include <regex>
+#include <climits>
 
 namespace BWidgets
 {

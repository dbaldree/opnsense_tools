--- aplay/formats.h.orig	2016-03-31 14:37:02 UTC
+++ aplay/formats.h
@@ -1,7 +1,6 @@
 #ifndef FORMATS_H
 #define FORMATS_H		1
 
-#include <endian.h>
 #include <byteswap.h>
 
 /* Definitions for .VOC files */

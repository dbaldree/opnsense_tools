--- src/AboutDialog.cpp.orig	2020-06-28 06:25:54 UTC
+++ src/AboutDialog.cpp
@@ -63,7 +63,7 @@ hold information about one contributor to Audacity.
 // RevisionIdent.h may contain #defines like these ones:
 //#define REV_LONG "28864acb238cb3ca71dda190a2d93242591dd80e"
 //#define REV_TIME "Sun Apr 12 12:40:22 2015 +0100"
-#include <RevisionIdent.h>
+//#include <RevisionIdent.h>
 
 #ifndef REV_TIME
 #define REV_TIME "unknown date and time"

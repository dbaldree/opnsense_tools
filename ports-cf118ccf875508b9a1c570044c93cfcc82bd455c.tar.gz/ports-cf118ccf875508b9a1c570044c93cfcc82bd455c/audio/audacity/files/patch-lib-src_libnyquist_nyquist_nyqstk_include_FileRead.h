--- lib-src/libnyquist/nyquist/nyqstk/include/FileRead.h.orig	2016-07-26 13:34:06 UTC
+++ lib-src/libnyquist/nyquist/nyqstk/include/FileRead.h
@@ -33,6 +33,7 @@
 #define STK_FILEREAD_H
 
 #include "Stk.h"
+#include <stdio.h>
 
 namespace Nyq
 {

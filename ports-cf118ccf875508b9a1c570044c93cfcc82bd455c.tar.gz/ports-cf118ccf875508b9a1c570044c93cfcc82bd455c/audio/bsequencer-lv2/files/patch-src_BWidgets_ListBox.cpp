--- src/BWidgets/ListBox.cpp.orig	2019-07-25 10:08:28 UTC
+++ src/BWidgets/ListBox.cpp
@@ -16,6 +16,7 @@
  */
 
 #include "ListBox.hpp"
+#include <sys/types.h>
 
 namespace BWidgets
 {

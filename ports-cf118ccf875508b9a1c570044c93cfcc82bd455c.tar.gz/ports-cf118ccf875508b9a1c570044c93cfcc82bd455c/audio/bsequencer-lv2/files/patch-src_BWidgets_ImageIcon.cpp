--- src/BWidgets/ImageIcon.cpp.orig	2019-07-25 10:05:26 UTC
+++ src/BWidgets/ImageIcon.cpp
@@ -16,6 +16,7 @@
  */
 
 #include "ImageIcon.hpp"
+#include <sys/types.h>
 
 namespace BWidgets
 {

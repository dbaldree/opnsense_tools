--- src/ButtonBox.hpp.orig	2019-09-18 08:50:30 UTC
+++ src/ButtonBox.hpp
@@ -1,6 +1,7 @@
 #ifndef BUTTONBOX_HPP_
 #define BUTTONBOX_HPP_
 
+#include <sys/types.h>
 #include <vector>
 #include <cmath>
 #include "BWidgets/BColors.hpp"

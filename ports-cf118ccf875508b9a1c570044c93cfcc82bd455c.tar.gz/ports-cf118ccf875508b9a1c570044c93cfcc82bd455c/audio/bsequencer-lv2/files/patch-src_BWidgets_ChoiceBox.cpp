--- src/BWidgets/ChoiceBox.cpp.orig	2019-07-25 10:03:27 UTC
+++ src/BWidgets/ChoiceBox.cpp
@@ -16,6 +16,7 @@
  */
 
 #include "ChoiceBox.hpp"
+#include <sys/types.h>
 
 namespace BWidgets
 {

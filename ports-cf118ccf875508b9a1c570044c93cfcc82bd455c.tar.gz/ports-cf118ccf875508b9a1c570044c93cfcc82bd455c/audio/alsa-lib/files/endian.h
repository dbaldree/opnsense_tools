#ifndef _ENDIAN_H
#define	_ENDIAN_H
#include <linux/types.h>
#endif /* _ENDIAN_H */

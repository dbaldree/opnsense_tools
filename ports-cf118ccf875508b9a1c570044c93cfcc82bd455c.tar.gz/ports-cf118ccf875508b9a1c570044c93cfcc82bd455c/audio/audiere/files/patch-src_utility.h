--- src/utility.h.orig	2006-02-14 04:57:01 UTC
+++ src/utility.h
@@ -10,6 +10,7 @@
 #include <map>
 #include <string>
 #include <utility>
+#include <cstdlib>
 #include "audiere.h"
 #include "types.h"
 

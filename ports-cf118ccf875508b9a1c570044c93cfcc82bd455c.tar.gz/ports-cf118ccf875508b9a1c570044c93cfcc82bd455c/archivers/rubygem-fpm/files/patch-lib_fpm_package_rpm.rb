--- lib/fpm/package/rpm.rb.orig	2019-12-03 14:42:58 UTC
+++ lib/fpm/package/rpm.rb
@@ -1,5 +1,4 @@
 require "fpm/package"
-require "backports"
 require "fileutils"
 require "find"
 require "arr-pm/file" # gem 'arr-pm'

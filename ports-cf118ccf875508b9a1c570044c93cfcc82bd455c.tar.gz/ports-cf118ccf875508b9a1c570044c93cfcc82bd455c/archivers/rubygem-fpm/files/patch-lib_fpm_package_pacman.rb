--- lib/fpm/package/pacman.rb.orig	2019-12-03 14:42:58 UTC
+++ lib/fpm/package/pacman.rb
@@ -1,7 +1,6 @@
 # -*- coding: utf-8 -*-
 require "fpm/package"
 require "fpm/util"
-require "backports"
 require "fileutils"
 require "find"
 

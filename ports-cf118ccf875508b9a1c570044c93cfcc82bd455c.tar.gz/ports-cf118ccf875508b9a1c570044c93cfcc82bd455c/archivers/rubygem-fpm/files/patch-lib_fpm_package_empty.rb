--- lib/fpm/package/empty.rb.orig	2019-12-03 14:42:58 UTC
+++ lib/fpm/package/empty.rb
@@ -1,5 +1,4 @@
 require "fpm/package"
-require "backports"
 
 # Empty Package type. For strict/meta/virtual package creation
 

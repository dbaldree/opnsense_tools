--- lib/fpm/package/dir.rb.orig	2019-12-03 14:42:58 UTC
+++ lib/fpm/package/dir.rb
@@ -1,6 +1,5 @@
 require "fpm/package"
 require "fpm/util"
-require "backports"
 require "fileutils"
 require "find"
 require "socket"

--- lib/fpm/package/zip.rb.orig	2019-12-03 14:42:58 UTC
+++ lib/fpm/package/zip.rb
@@ -1,4 +1,3 @@
-require "backports" # gem backports
 require "fpm/package"
 require "fpm/util"
 require "fileutils"

--- reporter.cc.orig	2014-01-07 20:30:56 UTC
+++ reporter.cc
@@ -4,6 +4,7 @@
 #include <string>
 #include <vector>
 #include <algorithm>
+#include <cassert>
 
 #include "asserts.h"
 #include "error.h"

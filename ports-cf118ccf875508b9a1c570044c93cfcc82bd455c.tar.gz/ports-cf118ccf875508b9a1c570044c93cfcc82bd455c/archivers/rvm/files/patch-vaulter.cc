--- vaulter.cc.orig	2014-11-12 13:09:24 UTC
+++ vaulter.cc
@@ -4,6 +4,7 @@
 #include <vector>
 #include <map>
 #include <string>
+#include <cassert>
 
 #include "asserts.h"
 #include "error.h"

--- 7z/Portable.h.orig	2012-12-08 22:16:47 UTC
+++ 7z/Portable.h
@@ -2,7 +2,7 @@
 #define __PORTABLE_H
 
 #include <string.h>
-#include <stdint.h>
+#include <inttypes.h>
 
 typedef signed char INT8;
 typedef unsigned char UINT8;

--- cfdblock.h.orig	1999-10-24 06:13:29 UTC
+++ cfdblock.h
@@ -14,7 +14,7 @@
 #ifndef __CFDBLOCK_H__
 #define __CFDBLOCK_H__
 
-#include <fstream.h>
+#include <fstream>
 #include "cftypes.h"
 #include "cfheader.h"
 

--- darray.h.orig	1999-10-24 11:29:53 UTC
+++ darray.h
@@ -155,4 +155,4 @@ void dynamic_array<ObjectType>::reset(si
 
 ///////////////////////////////////////***************************************
 
-#endif
\ No newline at end of file
+#endif

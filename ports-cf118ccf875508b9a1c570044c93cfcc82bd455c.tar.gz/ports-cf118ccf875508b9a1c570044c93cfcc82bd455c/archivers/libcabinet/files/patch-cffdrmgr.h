--- cffdrmgr.h.orig	1999-10-24 06:13:29 UTC
+++ cffdrmgr.h
@@ -9,7 +9,7 @@
 #ifndef __CFFDRMGR_H__
 #define __CFFDRMGR_H__
 
-#include <fstream.h>
+#include <fstream>
 #include "zlib.h"
 #include "cftypes.h"
 #include "cfdblock.h"

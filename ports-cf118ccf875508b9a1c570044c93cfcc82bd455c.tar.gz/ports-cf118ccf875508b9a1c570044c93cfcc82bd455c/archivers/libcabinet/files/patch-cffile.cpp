--- cffile.cpp.orig	1999-10-24 06:13:29 UTC
+++ cffile.cpp
@@ -17,7 +17,7 @@
 #ifndef __CFFILE_CPP__
 #define __CFFILE_CPP__
 
-#include <fstream.h>
+#include <fstream>
 #include "cffile.h"
 #include "cftypes.h"
 #include "cfheader.h"

--- cffdrmgr.cpp.orig	1999-10-24 11:29:53 UTC
+++ cffdrmgr.cpp
@@ -12,7 +12,7 @@
 #ifndef __CFFDRMGR_CPP__
 #define __CFFDRMGR_CPP__
 
-#include <fstream.h>
+#include <fstream>
 #include "zlib.h"
 #include "cftypes.h"
 #include "cfdblock.h"

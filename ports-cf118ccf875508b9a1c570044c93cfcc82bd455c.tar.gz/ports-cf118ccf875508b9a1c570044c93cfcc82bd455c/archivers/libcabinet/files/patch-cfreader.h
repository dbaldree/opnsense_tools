--- cfreader.h.orig	1999-10-24 06:13:29 UTC
+++ cfreader.h
@@ -11,7 +11,7 @@
 #ifndef __CFREADER_H__
 #define __CFREADER_H__
 
-#include <fstream.h>
+#include <fstream>
 #include "darray.h"
 #include "cffile.h"
 #include "cffdrmgr.h"

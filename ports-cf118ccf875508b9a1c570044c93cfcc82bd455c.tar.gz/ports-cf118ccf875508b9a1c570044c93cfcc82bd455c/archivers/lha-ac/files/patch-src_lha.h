--- src/lha.h.orig	2006-10-10 16:27:51 UTC
+++ src/lha.h
@@ -16,6 +16,7 @@
 #endif
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <errno.h>
 #include <ctype.h>
 #include <sys/types.h>

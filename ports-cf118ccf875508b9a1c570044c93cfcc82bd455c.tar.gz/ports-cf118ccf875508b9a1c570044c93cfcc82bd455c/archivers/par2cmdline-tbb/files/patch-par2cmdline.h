--- par2cmdline.h.orig	2009-02-03 05:14:49 UTC
+++ par2cmdline.h
@@ -428,6 +428,7 @@ typedef enum Result
 #include <vector>
 #include <map>
 #include <algorithm>
+#include <memory>
 
 #include <ctype.h>
 #include <iostream>
